// $Id: README.txt,v 1.25 2007/08/12 06:52:14 merlinofchaos Exp $

This is a rewrite of the Views module for Drupal 6. As of the above date,
it's still in the very early stages.
